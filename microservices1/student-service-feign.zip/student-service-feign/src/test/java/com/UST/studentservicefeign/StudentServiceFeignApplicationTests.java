package com.UST.studentservicefeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentServiceFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
