package com.UST.bookservices2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookServices2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
