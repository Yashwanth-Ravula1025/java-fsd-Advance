package com.UST.bookservices3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookServices3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
