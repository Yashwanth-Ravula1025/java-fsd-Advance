package com.UST.bookservices3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookServices3Application {

	public static void main(String[] args) {
		SpringApplication.run(BookServices3Application.class, args);
	}

}
