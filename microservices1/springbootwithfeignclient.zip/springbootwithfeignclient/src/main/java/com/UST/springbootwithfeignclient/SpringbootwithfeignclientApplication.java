package com.UST.springbootwithfeignclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootwithfeignclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootwithfeignclientApplication.class, args);
	}

}
