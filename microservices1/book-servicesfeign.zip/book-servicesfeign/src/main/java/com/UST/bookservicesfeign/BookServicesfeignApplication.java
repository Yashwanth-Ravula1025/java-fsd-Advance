package com.UST.bookservicesfeign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookServicesfeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookServicesfeignApplication.class, args);
	}

}
